import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
const $=id=>document.getElementById(id), panel=$('viewport');
let renderer;
try { renderer=new THREE.WebGLRenderer({antialias:true}); }
catch(e){$('status').textContent='浏览器无法创建 WebGL 渲染器';$('error').textContent=String(e);throw e;}
renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.localClippingEnabled=true;renderer.setClearColor(0x101b26);renderer.outputColorSpace=THREE.SRGBColorSpace;panel.appendChild(renderer.domElement);
const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(38,1,.05,1500);camera.up.set(0,0,1);
const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.maxDistance=450;
scene.add(new THREE.HemisphereLight(0xe1f0ff,0x42515b,2.5));
for(const [pos,intensity] of [[[-30,-40,100],3],[[20,25,100],2]]){const l=new THREE.DirectionalLight(0xffffff,intensity);l.position.set(...pos);scene.add(l);}
const grid=new THREE.GridHelper(160,32,0x34576c,0x203747);grid.rotation.x=Math.PI/2;grid.position.z=-.04;scene.add(grid);
const plane=new THREE.Plane(new THREE.Vector3(0,-1,0),0), root=new THREE.Group();root.rotation.x=Math.PI/2;scene.add(root);
const records=[], byId=new Map();let mode='nacelle',selected=null,metadata=new Map();
const exterior=id=>id.startsWith('COVER.')||id==='ROTOR.SPINNER';
const tower=d=>d.System.startsWith('01 ')||d.System.startsWith('02 ')||d.System.startsWith('12 ')||d.AssetId==='ELEC.TRANSFORMER';
const offsets={'06 传动链':[0,1.7,0],'07 发电与电气':[1.7,3.2,0],'09 冷却与安全':[0,4.5,0],'11 轮毂与变桨':[-2,0,0],'10 检修设施':[0,0,2]};
function visibility(){const sys=$('system').value,q=$('search').value.trim().toLowerCase(),expl=+$('explode').value/100;$('explodeValue').textContent=Math.round(expl*100)+'%';
 for(const r of records){const d=r.object.userData;r.object.visible=(mode==='whole'||!tower(d))&&($('cover').checked||!exterior(d.AssetId))&&(!sys||d.System===sys);r.object.position.copy(r.base);const off=offsets[d.System];if(off)r.object.position.addScaledVector(new THREE.Vector3(...off),expl);}
 const visible=records.filter(r=>(!sys||r.object.userData.System===sys)&&(!q||(r.object.userData.AssetId+' '+r.object.userData.NameCN).toLowerCase().includes(q)));
 $('list').replaceChildren();for(const r of visible){const d=r.object.userData,b=document.createElement('button');b.textContent=d.NameCN;const small=document.createElement('small');small.textContent=d.AssetId;b.append(small);if(selected===r)b.classList.add('active');b.onclick=()=>{select(r);if(!r.object.visible){$('system').value=d.System;if(exterior(d.AssetId))$('cover').checked=true;if(tower(d))setMode('whole');visibility();}focus(r)};$('list').append(b);}$('count').textContent=visible.length;
}
function view(pos,target){camera.position.set(...pos);controls.target.set(...target);controls.update();}
function setMode(m){mode=m;$('nacelle').classList.toggle('active',m==='nacelle');$('whole').classList.toggle('active',m==='whole');grid.visible=m==='whole';if(m==='whole')view([-150,-175,120],[0,0,62]);else view([-12,-18,92],[2,0,80.5]);visibility();}
function select(r){if(selected)selected.object.traverse(o=>{if(o.isMesh)o.material.emissive?.setHex(0)});selected=r;const d=r.object.userData,meta=metadata.get(d.AssetId)||{};r.object.traverse(o=>{if(o.isMesh)o.material.emissive?.setHex(0x125267)});const el=$('detail');el.replaceChildren();const h=document.createElement('h3');h.textContent=d.NameCN;el.append(h);const dl=document.createElement('dl');
 const entries=[['构件编号',d.AssetId],['IFC GUID',meta.ifc_guid||'见 ifc_mapping.json'],['所属系统',d.System],['IFC 类型',d.IfcClass],['几何依据',d.Evidence],['世界坐标包络 / 米',(meta.dimensions||[]).map(n=>n.toFixed(3)).join(' × ')+'（非加工尺寸）'],['来源',d.Source],['重建说明',d.Notes],['运行数据','未连接；无模拟实时值']];
 for(const [title,value] of entries){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=title;dd.textContent=value;dl.append(dt,dd);}el.append(dl);$('selection').hidden=false;visibility();}
function focus(r){const b=new THREE.Box3().setFromObject(r.object),center=b.getCenter(new THREE.Vector3()),size=b.getSize(new THREE.Vector3()).length();const dir=new THREE.Vector3(-1,-1.5,.8).normalize();controls.target.copy(center);camera.position.copy(center).addScaledVector(dir,Math.max(3,size*1.8));controls.update();}
$('selection').onclick=()=>{if(!selected)return;const d=selected.object.userData;$('system').value='';if(exterior(d.AssetId))$('cover').checked=true;if(tower(d)&&mode!=='whole')setMode('whole');visibility();focus(selected)};$('nacelle').onclick=()=>setMode('nacelle');$('whole').onclick=()=>setMode('whole');$('side').onclick=()=>view(mode==='whole'?[0,-240,65]:[2,-26,80.5],mode==='whole'?[0,0,65]:[2,0,80.5]);
$('reset').onclick=()=>{$('search').value='';$('system').value='';$('explode').value=0;$('cover').checked=false;$('cut').checked=false;clip();setMode('nacelle')};
for(const id of ['cover','system','search','explode'])$(id).addEventListener('input',visibility);
function clip(){for(const r of records)r.object.traverse(o=>{if(o.isMesh){o.material.clippingPlanes=$('cut').checked?[plane]:[];o.material.needsUpdate=true;}})}$('cut').onchange=clip;
const ray=new THREE.Raycaster(),mouse=new THREE.Vector2();let down;
renderer.domElement.addEventListener('pointerdown',e=>down=[e.clientX,e.clientY]);renderer.domElement.addEventListener('pointerup',e=>{if(!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>5)return;const b=renderer.domElement.getBoundingClientRect();mouse.set((e.clientX-b.left)/b.width*2-1,-(e.clientY-b.top)/b.height*2+1);ray.setFromCamera(mouse,camera);const hits=ray.intersectObject(root,true);for(const hit of hits){let n=hit.object,visible=true,record;while(n){if(!n.visible)visible=false;if(n.userData.AssetId)record=byId.get(n.userData.AssetId);n=n.parent;}if(visible&&record&&(!$('cut').checked||plane.distanceToPoint(hit.point)>=0)){select(record);break;}}});
function resize(){renderer.setSize(panel.clientWidth,panel.clientHeight);camera.aspect=panel.clientWidth/panel.clientHeight;camera.updateProjectionMatrix();}new ResizeObserver(resize).observe(panel);
try{
 const embedded=window.BIM_EMBEDDED;
 const model=embedded?new GLTFLoader().parseAsync(Uint8Array.from(atob(embedded.glb),c=>c.charCodeAt(0)).buffer,''):new GLTFLoader().loadAsync('../models/V90_reconstruction.glb');
 const [gltf,meta]=await Promise.all([model,embedded?embedded.metadata:fetch('../data/components.json').then(r=>{if(!r.ok)throw Error('构件数据加载失败');return r.json()})]);
 metadata=new Map(meta.components.map(c=>[c.id,c]));root.add(gltf.scene);gltf.scene.traverse(o=>{if(o.userData.AssetId){const r={object:o,base:o.position.clone()};records.push(r);byId.set(o.userData.AssetId,r);}if(o.isMesh){o.material=o.material.clone();o.material.side=THREE.DoubleSide;}});
 for(const sys of [...new Set(records.map(r=>r.object.userData.System))].sort()){const o=document.createElement('option');o.value=sys;o.textContent=sys;$('system').append(o);}setMode('nacelle');$('status').textContent=`${records.length} 个构件 · 点击部件查看来源与重建精度`;window.BIM_VIEWER={scene,root,records,renderer,camera,controls};
}catch(e){$('status').textContent='模型加载失败';$('error').textContent=(window.BIM_EMBEDDED?'内嵌模型解析失败，请使用支持 WebGL 的现代浏览器。\n':'请通过本地 HTTP 服务打开本页面。\n')+String(e);}
renderer.setAnimationLoop(()=>{controls.update();renderer.render(scene,camera)});
