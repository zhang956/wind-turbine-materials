"""Serve only this delivery's parent directory. No external dependencies."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import argparse
p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8788);p.add_argument('--bind',default='127.0.0.1');a=p.parse_args()
root=Path(__file__).resolve().parent
try:
 server=ThreadingHTTPServer((a.bind,a.port),partial(SimpleHTTPRequestHandler,directory=str(root)))
except OSError as exc:
 raise SystemExit(f'无法监听 {a.bind}:{a.port}: {exc}；请使用 --port 指定空闲端口。')
print(f'浏览地址：http://{a.bind}:{server.server_port}/viewer/ ；按 Ctrl+C 停止。',flush=True)
try:server.serve_forever()
except KeyboardInterrupt:pass
finally:server.server_close()
